package raven.table;

public interface EventCellInputChange {

    public void inputChanged();
}
